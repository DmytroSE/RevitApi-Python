# -*- coding: UTF-8 -*-
import os
import os.path as op
import math
from pyrevit import framework
from pyrevit import script, revit
from pyrevit import DB, UI
from pyrevit import forms
from pyrevit.coreutils import envvars

SYNC_VIEW_ENV_VAR = 'TESTVIEW'
def copyzoomstate(sender, args):
    if script.get_envvar(SYNC_VIEW_ENV_VAR):
        forms.alert('view activating')

def applyzoomstate(sender, args):
    if script.get_envvar(SYNC_VIEW_ENV_VAR):
        forms.alert('view activated')

def get_data_filename(document):
    project_name = op.splitext(op.basename(document.PathName))[0]
    return project_name + '_pySyncRevitActiveViewZoomState'

def event_handler_function(sender, args):
    forms.alert('View avtivated!')

def togglestate():
    new_state = not script.get_envvar(SYNC_VIEW_ENV_VAR)
    if new_state:
        data_filename = get_data_filename(revit.doc)
        if os.path.exists(data_filename):
            os.remove(data_filename)
    script.set_envvar(SYNC_VIEW_ENV_VAR, new_state)
    script.toggle_icon(new_state)
    #print(envvars.get_pyrevit_env_vars())
    #print(script.get_envvar(SYNC_VIEW_ENV_VAR))

def __selfinit__(script_cmp, ui_button_cmp, __rvt__):
    try:
        __rvt__.ViewActivating += \
            framework.EventHandler[
                UI.Events.ViewActivatingEventArgs](copyzoomstate)
        __rvt__.ViewActivated += \
            framework.EventHandler[
                UI.Events.ViewActivatedEventArgs](applyzoomstate)
        return True
    except Exception:
        return False

if __name__ == '__main__':
    togglestate()
